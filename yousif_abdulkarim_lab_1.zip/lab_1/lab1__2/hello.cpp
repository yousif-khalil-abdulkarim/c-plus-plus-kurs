#include <iostream>

int main(int argc, char *argv[])
{
	std::cout << "Hello World! Nice to see you, " << argv[1] << " " << argv[2] << "!" << std::endl;
	return 0;
}