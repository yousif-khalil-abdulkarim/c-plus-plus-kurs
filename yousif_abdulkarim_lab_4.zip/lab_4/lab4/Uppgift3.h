#ifndef UPPGFIT_3
#define UPPGFIT_3
bool Even(int nbr);
void Uppgift3();
#endif