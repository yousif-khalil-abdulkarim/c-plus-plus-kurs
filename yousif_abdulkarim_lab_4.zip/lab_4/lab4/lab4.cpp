#include "uppgift1.h"
#include "Uppgift2.h"
#include "Uppgift3.h"

int main()
{
    // Uppgift1A();
    // Uppgift1B();
    // Uppgift1C();
    // Uppgift1D();
    // Uppgift2A();
    // Uppgift2B();
    // Uppgift3();
}