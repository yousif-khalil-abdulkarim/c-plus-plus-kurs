#ifndef UPPGIFT_2
#define UPPGIFT_2
#include<string>

void Uppgift2A();

void Uppgift2B();

#endif