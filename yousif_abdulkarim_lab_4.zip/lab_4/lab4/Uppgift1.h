#ifndef UPPGFIT_1
#define UPPGFIT_1
void Uppgift1A();
void Uppgift1B();
void Uppgift1C();
void Uppgift1D();
#endif