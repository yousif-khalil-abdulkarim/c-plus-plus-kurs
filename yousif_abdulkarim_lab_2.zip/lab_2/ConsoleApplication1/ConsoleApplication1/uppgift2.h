#include <string>
#ifndef UPPGIFT_2
#define UPPGIFT_2
void substitute_str(
	std::string& iostring,
	const std::string& before,
	const std::string& after
);
#endif