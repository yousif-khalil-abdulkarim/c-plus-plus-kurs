#ifndef UPPGIFT_1
#define UPPGIFT_1
int gcd(int nbrA, int nbrB);

bool isPrimeNbr(int* primesArray, int* primesArraySize, int nbrToCheck);

void printPrimeNbrs(int n);
#endif